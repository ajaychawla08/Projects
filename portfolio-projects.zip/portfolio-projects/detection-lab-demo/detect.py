#!/usr/bin/env python3
"""Runs the detection logic from ../sigma-detections over the synthetic events and prints alerts.

The per-event rules mirror the Sigma YAML; the brute-force rule is a correlation
(many failures, then a success) that plain Sigma cannot express on its own.
"""
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta

PS = ("\\powershell.exe", "\\pwsh.exe")


def rules(e):
    img, cli = e.get("Image", "").lower(), e.get("CommandLine", "")
    low = cli.lower()
    eid = e["EventID"]
    if eid == 1 and img.endswith(PS) and any(x in low for x in (" -enc ", " -encodedcommand ", " -ec ")):
        yield "PowerShell Encoded Command", "medium", "T1059.001 / T1027"
    if eid == 1 and img.endswith("\\certutil.exe") and ("urlcache" in low or "verifyctl" in low):
        yield "Certutil Download", "high", "T1105"
    if eid == 1 and img.endswith("\\schtasks.exe") and " /create " in low and any(
            p in low for p in ("\\appdata\\", "\\users\\public\\", "\\temp\\")):
        yield "Scheduled Task To User-Writable Path", "medium", "T1053.005"
    if eid == 4732 and e.get("TargetUserName") == "Administrators":
        yield "Member Added To Local Administrators", "medium", "T1098"
    if eid in (1102, 104):
        yield "Event Log Cleared", "high", "T1070.001"


def brute_force_then_success(events, fail_threshold=10, window=timedelta(minutes=5), after=timedelta(minutes=10)):
    fails = defaultdict(list)
    for e in events:
        ts = datetime.fromisoformat(e["Timestamp"])
        key = (e.get("IpAddress"), e.get("TargetUserName"))
        if e["EventID"] == 4625:
            fails[key].append(ts)
        elif e["EventID"] == 4624 and key in fails:
            recent = [t for t in fails[key] if ts - t <= after]
            burst = max((sum(1 for u in recent if 0 <= (u - t).total_seconds() <= window.total_seconds()) for t in recent), default=0)
            if burst >= fail_threshold:
                yield e, f"{len(recent)} failed logons then success for {key[1]} from {key[0]}"


def main(path):
    events = [json.loads(l) for l in open(path)]
    alerts = []
    for e in events:
        for name, level, attack in rules(e):
            alerts.append((e["Timestamp"], level, name, attack, e.get("CommandLine") or e.get("MemberName") or ""))
    for e, detail in brute_force_then_success(events):
        alerts.append((e["Timestamp"], "high", "Brute Force Followed By Success", "T1110", detail))
    for ts, level, name, attack, detail in sorted(alerts):
        print(f"{ts[11:]}  {level.upper():<7} {name:<38} {attack:<18} {detail[:70]}")
    print(f"\n{len(events)} events scanned, {len(alerts)} alerts")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "synthetic_events.jsonl")
