# IOC enricher

Classifies indicators (IP, domain, hash), looks them up, and prints a triage table with a verdict. Output is defanged (`1[.]2[.]3[.]4`) so it is safe to paste into tickets.

```
python3 enrich.py sample_iocs.txt --offline        # no keys needed
export VT_API_KEY=...; export ABUSEIPDB_API_KEY=...
python3 enrich.py my_iocs.txt                      # live lookups
```

Verdict rule: MALICIOUS if VirusTotal malicious engines >= 3 or AbuseIPDB score >= 50; SUSPICIOUS if any detection or score >= 25. **The offline sample responses are made up for demonstration and are not real reputation data.** Live mode uses the VirusTotal v3 and AbuseIPDB v2 APIs and was not run against them here, so test it with your own keys and mind their rate limits. Standard library only.
