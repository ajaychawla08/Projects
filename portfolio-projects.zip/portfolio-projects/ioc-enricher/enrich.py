#!/usr/bin/env python3
"""IOC enrichment: classify IPs, domains and hashes, look them up, print a triage table.

Live mode needs API keys in the environment (VT_API_KEY, ABUSEIPDB_API_KEY).
--offline uses sample_responses.json so you can try it without keys.
Standard library only.
"""
import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request

IPV4 = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")
HASH = re.compile(r"^(?:[a-fA-F0-9]{32}|[a-fA-F0-9]{40}|[a-fA-F0-9]{64})$")
DOMAIN = re.compile(r"^(?=.{4,253}$)(?:[a-z0-9-]{1,63}\.)+[a-z]{2,}$", re.I)


def classify(ioc):
    if IPV4.match(ioc) and all(int(o) <= 255 for o in ioc.split(".")):
        return "ip"
    if HASH.match(ioc):
        return "hash"
    if DOMAIN.match(ioc):
        return "domain"
    return None


def defang(ioc):
    return ioc.replace(".", "[.]")


def http_json(url, headers):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.load(r)


def lookup_live(ioc, kind):
    out = {"vt_malicious": None, "vt_suspicious": None, "abuse_score": None, "note": ""}
    vt_key, ab_key = os.getenv("VT_API_KEY"), os.getenv("ABUSEIPDB_API_KEY")
    path = {"ip": "ip_addresses", "domain": "domains", "hash": "files"}[kind]
    try:
        if vt_key:
            data = http_json(f"https://www.virustotal.com/api/v3/{path}/{ioc}", {"x-apikey": vt_key})
            stats = data["data"]["attributes"]["last_analysis_stats"]
            out["vt_malicious"], out["vt_suspicious"] = stats.get("malicious", 0), stats.get("suspicious", 0)
        if kind == "ip" and ab_key:
            data = http_json(f"https://api.abuseipdb.com/api/v2/check?ipAddress={ioc}&maxAgeInDays=90",
                             {"Key": ab_key, "Accept": "application/json"})
            out["abuse_score"] = data["data"]["abuseConfidenceScore"]
    except urllib.error.HTTPError as e:
        out["note"] = f"HTTP {e.code}"
    except Exception as e:  # network errors should not stop the whole run
        out["note"] = type(e).__name__
    if not vt_key and not ab_key:
        out["note"] = "no API keys set"
    return out


def verdict(r):
    vt, sus, ab = r["vt_malicious"] or 0, r["vt_suspicious"] or 0, r["abuse_score"] or 0
    if vt >= 3 or ab >= 50:
        return "MALICIOUS"
    if vt >= 1 or sus >= 1 or ab >= 25:
        return "SUSPICIOUS"
    if r["vt_malicious"] is None and r["abuse_score"] is None:
        return "UNKNOWN"
    return "CLEAN"


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("file", help="text file with one IOC per line")
    p.add_argument("--offline", action="store_true", help="use bundled sample responses")
    a = p.parse_args()

    sample = json.load(open(os.path.join(os.path.dirname(__file__), "sample_responses.json"))) if a.offline else {}
    iocs = [l.strip() for l in open(a.file) if l.strip() and not l.startswith("#")]

    print(f"| {'IOC':<44} | {'Type':<6} | {'VT mal/sus':<10} | {'Abuse':<5} | {'Verdict':<10} |")
    print(f"|{'-'*46}|{'-'*8}|{'-'*12}|{'-'*7}|{'-'*12}|")
    for ioc in iocs:
        kind = classify(ioc)
        if not kind:
            print(f"| {ioc[:44]:<44} | {'?':<6} | {'-':<10} | {'-':<5} | {'INVALID':<10} |")
            continue
        r = sample.get(ioc, {"vt_malicious": None, "vt_suspicious": None, "abuse_score": None}) if a.offline \
            else lookup_live(ioc, kind)
        vt = "-" if r["vt_malicious"] is None else f"{r['vt_malicious']}/{r['vt_suspicious']}"
        ab = "-" if r["abuse_score"] is None else str(r["abuse_score"])
        shown = defang(ioc) if kind != "hash" else ioc[:16] + "..."
        print(f"| {shown:<44} | {kind:<6} | {vt:<10} | {ab:<5} | {verdict(r):<10} |")


if __name__ == "__main__":
    sys.exit(main())
