# Security portfolio projects

1. `log-source-health-checker/`: finds SIEM log sources that stopped reporting.
2. `sigma-detections/`: five Sigma rules mapped to MITRE ATT&CK.
3. `ioc-enricher/`: classifies and enriches IPs, domains and hashes.
4. `detection-lab-demo/`: synthetic intrusion plus the detections that catch it.
5. `writeups/`: three investigation write-ups based on the synthetic scenario.

All data is sample or synthetic. Nothing here comes from a real employer or system.
