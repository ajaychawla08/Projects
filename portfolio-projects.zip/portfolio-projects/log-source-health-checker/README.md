# Log-source health checker

Finds log sources that have stopped reporting to a SIEM. It reads a SIEM export (`ip, log_type, last_log_time`) and a list of expected IPs, then marks each source **OK** or **No Logs** against a threshold (default 60 minutes).

```
python3 checker.py --export sample_export.csv --inventory sample_inventory.txt --threshold-minutes 60 --out result.csv
```

- Takes the newest timestamp when an IP/log type appears several times.
- A blank IP cell (as in merged Excel cells) reuses the IP above it.
- IPs in the inventory but missing from the export are reported as No Logs.
- Exit code is 1 when anything is No Logs, so it can run in a scheduled job.
- Reads `.xlsx` if `openpyxl` is installed.

Sample data uses documentation-range IPs only. **Ideas to extend:** per-SIEM column mapping, email/chat notification, writing results straight to a status sheet.
