#!/usr/bin/env python3
"""Log-source health checker.

Compares a SIEM export (ip, log_type, last_log_time) with an inventory of
expected IPs and marks every source OK or No Logs against a time threshold.
Works on CSV; reads .xlsx too if openpyxl is installed.
"""
import argparse
import csv
import sys
from datetime import datetime, timedelta

TIME_FORMATS = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%d-%m-%Y %H:%M:%S")


def parse_time(value):
    value = (value or "").strip()
    for fmt in TIME_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def read_rows(path):
    if path.lower().endswith(".xlsx"):
        try:
            from openpyxl import load_workbook
        except ImportError:
            sys.exit("Reading .xlsx needs openpyxl: pip install openpyxl")
        sheet = load_workbook(path, read_only=True, data_only=True).active
        rows = [[("" if c is None else str(c)) for c in r] for r in sheet.iter_rows(values_only=True)]
        header, body = rows[0], rows[1:]
        return [dict(zip(header, r)) for r in body]
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def load_export(path):
    """Return {ip: {log_type: newest datetime}}. A blank IP (merged cell) reuses the row above."""
    sources, last_ip = {}, ""
    for row in read_rows(path):
        ip = (row.get("ip") or "").strip() or last_ip
        last_ip = ip
        if not ip:
            continue
        log_type = (row.get("log_type") or "unknown").strip()
        seen = parse_time(row.get("last_log_time"))
        if seen is None:
            continue
        current = sources.setdefault(ip, {}).get(log_type)
        if current is None or seen > current:
            sources[ip][log_type] = seen
    return sources


def load_inventory(path):
    with open(path, encoding="utf-8") as f:
        return [l.strip() for l in f if l.strip() and not l.startswith("#")]


def check(inventory, sources, now, threshold):
    results = []
    for ip in inventory:
        if ip not in sources:
            results.append((ip, "-", "", "No Logs", "IP not present in export"))
            continue
        for log_type, seen in sorted(sources[ip].items()):
            age = now - seen
            status = "OK" if age <= threshold else "No Logs"
            note = f"last log {int(age.total_seconds() // 60)} min ago"
            results.append((ip, log_type, seen.strftime("%Y-%m-%d %H:%M:%S"), status, note))
    return results


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--export", required=True, help="SIEM export (.csv or .xlsx)")
    p.add_argument("--inventory", required=True, help="text file, one expected IP per line")
    p.add_argument("--threshold-minutes", type=int, default=60)
    p.add_argument("--now", help="override current time (YYYY-MM-DD HH:MM:SS), useful for tests")
    p.add_argument("--out", help="write results to this CSV file")
    a = p.parse_args()

    now = parse_time(a.now) if a.now else datetime.now()
    results = check(load_inventory(a.inventory), load_export(a.export), now,
                    timedelta(minutes=a.threshold_minutes))

    print(f"{'IP':<16}{'LOG TYPE':<14}{'STATUS':<9}NOTE")
    for ip, lt, _, status, note in results:
        print(f"{ip:<16}{lt:<14}{status:<9}{note}")
    bad = sum(1 for r in results if r[3] != "OK")
    print(f"\n{len(results) - bad} OK, {bad} No Logs (threshold {a.threshold_minutes} min)")

    if a.out:
        with open(a.out, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["ip", "log_type", "last_log_time", "status", "note"])
            w.writerows(results)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
