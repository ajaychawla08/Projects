# Sigma detections mapped to MITRE ATT&CK

| Rule | Technique | Level | Main false positive |
|---|---|---|---|
| PowerShell Encoded Command | T1059.001, T1027 | medium | Deployment/management tools |
| Windows Event Log Cleared | T1070.001 | high | Planned log maintenance |
| Member Added To Local Administrators | T1098 | medium | IT provisioning (check tickets) |
| Certutil Used To Download A File | T1105 | high | Rare admin use |
| Scheduled Task To User-Writable Path | T1053.005 | medium | Installers registering update tasks |

`python3 validate.py` checks required fields and ATT&CK tags (needs `pyyaml`). Convert the rules to your SIEM's query language with `sigma-cli` or `pySigma`. `../detection-lab-demo` runs the same logic against synthetic events.
