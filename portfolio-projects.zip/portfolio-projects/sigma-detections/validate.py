#!/usr/bin/env python3
"""Checks every rule has the required Sigma fields and at least one ATT&CK technique tag."""
import glob, re, sys, yaml

REQUIRED = ["title", "id", "status", "description", "logsource", "detection", "falsepositives", "level", "tags"]
failed = False
for path in sorted(glob.glob("rules/*.yml")):
    rule = yaml.safe_load(open(path))
    missing = [k for k in REQUIRED if k not in rule]
    has_cond = "condition" in rule.get("detection", {})
    techniques = [t for t in rule.get("tags", []) if re.fullmatch(r"attack\.t\d{4}(\.\d{3})?", t)]
    ok = not missing and has_cond and techniques
    failed |= not ok
    print(f"{'PASS' if ok else 'FAIL'}  {path}  {', '.join(t[7:].upper() for t in techniques)}"
          + (f"  missing={missing}" if missing else ""))
sys.exit(1 if failed else 0)
